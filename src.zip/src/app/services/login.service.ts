import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root',
})
export class LoginService {
  private apiUrl = `${environment.apiUrl}`;
  constructor(private http: HttpClient, private router: Router) {}

  login(data: any) {
    const loginUrl = `${this.apiUrl}/user/login`;
    return this.http.post(loginUrl, data);
  }

  navRoute(routeUrl: string) {
    this.router.navigate([routeUrl]);
  }
}
