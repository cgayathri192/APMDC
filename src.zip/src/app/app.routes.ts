import { Routes } from '@angular/router';
import { ReportFormComponent } from './report-form/report-form.component';

export const routes: Routes = [
  
  {
    path:'reportform',
    component:ReportFormComponent
  },
  {
    path: '',
    redirectTo: 'auth',
    pathMatch: 'full',
  },
  {
    path: 'auth',
    loadChildren: () => import('./auth.routes'),
  },
  {
    path: 'sdvs',
    loadChildren: () => import('./features/feature.routes'),
  },
  {
    path: '**',
    redirectTo: 'auth',
    pathMatch: 'full',
  }
];
