import { Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TicketCardComponent } from '../ui/ticket-card/ticket-card.component';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { ReceiptUiComponent } from '../ui/receipt-ui/receipt-ui.component';
import { NgxPrintModule } from 'ngx-print';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    TicketCardComponent,
    ReceiptUiComponent,
    ReactiveFormsModule,
    NgxPrintModule,
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent {
  activeCard: number = 0;
  @ViewChild('exModal') myModal: any;

  tickets = [
    { id: 1, name: 'ఆంత్రాలయ దర్శనం (అర్చన)', count: 250, amount: 100 },
    { id: 2, name: 'కుంకుమార్చన', count: 250, amount: 100 },
    { id: 3, name: 'గణపతి అర్చన', count: 300, amount: 100 },
    { id: 4, name: 'సుప్రభాత సేవ', count: 300, amount: 100 },
    { id: 5, name: 'ఏకాంత సేవ', count: 300, amount: 100 },
    { id: 6, name: 'లడ్డు', count: 300, amount: 100 },
    { id: 7, name: 'చక్కెర పొంగలి', count: 300, amount: 100 },
    { id: 8, name: 'పులిహూర', count: 300, amount: 100 },
  ];

  ticketEntries: FormControl = new FormControl('', [Validators.required]);

  updateCount() {
    if (this.ticketEntries.valid) {
      let prevCount = this.tickets[this.activeCard].count;
      this.tickets[this.activeCard].count =
        +this.ticketEntries.value + prevCount;
      this.ticketEntries.reset();
      // this.myModal.nativeElement.click();
    } else {
      alert('Please enter a valid number');
      return;
    }
  }
}
