import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from '../header/header.component';

@Component({
  selector: 'app-auth',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent],
  template: `
    <app-header [tag]="'login'"></app-header>
    <router-outlet></router-outlet>
  `,
})
export class AuthComponent {}
