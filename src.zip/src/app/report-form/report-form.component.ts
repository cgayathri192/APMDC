import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import jsPDF from 'jspdf';
import 'jspdf-autotable'; 

@Component({
  selector: 'app-report-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './report-form.component.html',
  styleUrls: ['./report-form.component.css']
})
export class ReportFormComponent {
  reportForm: FormGroup;
  categories = [
    { id: 1, name: 'ఆంత్రాలయ దర్శనం (అర్చన)', count: 250, amount: 100 },
    { id: 2, name: 'కుంకుమార్చన', count: 250, amount: 100 },
    { id: 3, name: 'గణపతి అర్చన', count: 300, amount: 100 },
    { id: 4, name: 'సుప్రభాత సేవ', count: 300, amount: 100 },
    { id: 5, name: 'ఏకాంత సేవ', count: 300, amount: 100 },
    { id: 6, name: 'లడ్డు', count: 300, amount: 100 },
    { id: 7, name: 'చక్కెర పొంగలి', count: 300, amount: 100 },
    { id: 8, name: 'పులిహూర', count: 300, amount: 100 }
  ];

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.reportForm = this.fb.group({
      category: ['', Validators.required],
      date: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.reportForm.valid) {
      const formData = this.reportForm.value;
      const apiUrl = `${environment.apiUrl}/info/generateDocument`;

      this.http.post(apiUrl, formData, { responseType: 'text' }).subscribe(
        (response: string) => {
          this.generatePdf(response);
        },
        error => {
          console.error('Error generating document:', error);
        }
      );
    } else {
      console.log('Form is not valid');
    }
  }

  private generatePdf(content: string): void {
    const doc = new jsPDF();

    doc.text(content, 10, 10); 

    doc.save('report.pdf'); 
  }
}
