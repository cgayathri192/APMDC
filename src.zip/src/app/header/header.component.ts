import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportFormComponent } from '../report-form/report-form.component';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule,ReportFormComponent,RouterModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent {
  @Input() tag: string = 'login';
}
