import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxPrintModule } from 'ngx-print';

@Component({
  selector: 'app-receipt-ui',
  standalone: true,
  imports: [CommonModule, NgxPrintModule],
  templateUrl: './receipt-ui.component.html',
  styleUrls: ['./receipt-ui.component.css'],
})
export class ReceiptUiComponent {
  newDate: Date = new Date();

  @Input() sevaInfo: { id: number; name: string; amount: number } = {
    id: 0,
    name: '',
    amount: 0,
  };
}
