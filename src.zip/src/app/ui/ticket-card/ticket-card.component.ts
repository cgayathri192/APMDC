import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

interface CardIntf {
  count: number;
  name: string;
}

@Component({
  selector: 'app-ticket-card',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './ticket-card.component.html',
  styleUrls: ['./ticket-card.component.css'],
})
export class TicketCardComponent {
  @Input() cardInfo: CardIntf = {
    count: 0,
    name: '',
  };
}
